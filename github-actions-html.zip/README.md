# github-actions-html
 Automatically build & deploy my personal Website of mustafaoz.dev by using Github-Actions.
